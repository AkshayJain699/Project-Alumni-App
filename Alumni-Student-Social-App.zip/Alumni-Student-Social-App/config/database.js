module.exports = {
  database:'mongodb://localhost:27017/?directConnection=true'
//  secret: 'yoursecret'
}
